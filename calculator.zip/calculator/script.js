document.addEventListener('DOMContentLoaded', () => {
    const result = document.getElementById('result');
    let currentInput = '';
    
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', () => {
            const value = button.textContent;
            
            if (value === '=') {
                try {
                    currentInput = eval(currentInput);
                    result.value = currentInput;
                } catch {
                    result.value = 'Error';
                }
            } else if (value === 'C') {
                currentInput = '';
                result.value = '';
            } else if (value === 'DEL') {
                currentInput = currentInput.slice(0, -1);
                result.value = currentInput;
            } else {
                currentInput += value;
                result.value = currentInput;
            }
        });
    });
});