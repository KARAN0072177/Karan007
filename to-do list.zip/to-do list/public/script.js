// Function to load tasks from localStorage
function loadTasks() {
    const savedTasks = JSON.parse(localStorage.getItem('tasks')) || [];
    savedTasks.forEach(task => addTaskToDOM(task.text, task.completed));
}

// Function to add a task to the DOM
function addTaskToDOM(taskText, isCompleted = false) {
    const li = document.createElement('li');
    li.textContent = taskText;

    if (isCompleted) {
        li.classList.add('completed');
    }

    // Add a checkbox
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = isCompleted;
    checkbox.addEventListener('change', () => {
        li.classList.toggle('completed');
        updateLocalStorage();
    });

    // Add a delete button
    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = 'Delete';
    deleteBtn.addEventListener('click', () => {
        li.remove();
        updateLocalStorage();
    });

    li.appendChild(checkbox);
    li.appendChild(deleteBtn);

    document.querySelector('ul').appendChild(li);
}

// Function to update LocalStorage with current tasks
function updateLocalStorage() {
    const tasks = [];
    document.querySelectorAll('li').forEach(li => {
        tasks.push({
            text: li.textContent.replace('Delete', '').trim(),
            completed: li.classList.contains('completed')
        });
    });
    localStorage.setItem('tasks', JSON.stringify(tasks));
}

// Add task event
document.querySelector('button').addEventListener('click', () => {
    const taskInput = document.querySelector('input');
    if (taskInput.value.trim()) {
        addTaskToDOM(taskInput.value.trim());
        updateLocalStorage();
        taskInput.value = ''; // Clear input field
    }
});

// Load tasks from localStorage on page load
window.addEventListener('DOMContentLoaded', loadTasks);